name = "pbiapi"

from .pbiapi import PowerBIAPIClient
